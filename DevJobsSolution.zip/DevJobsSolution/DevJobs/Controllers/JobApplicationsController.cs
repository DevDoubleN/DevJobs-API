﻿using DevJobs.Entities;
using DevJobs.Models;
using DevJobs.Persistence;
using DevJobs.Persistence.Repositories;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace DevJobs.Controllers
{
    [Route("api/job-vacancies/applications")]
    [ApiController]
    public class JobApplicationsController : ControllerBase
    {
        #region Members

        private readonly IJobVacancyRepository _jobVacancyRepository;

        #endregion

        #region Constructor
        public JobApplicationsController(IJobVacancyRepository jobVacancyRepository)
        {
            _jobVacancyRepository = jobVacancyRepository;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Cadastrar uma aplicação para uma vaga.
        /// </summary>
        /// <remarks>
        /// {
        ///"applicantName": "string",
        ///"applicantEmail": "string",
        ///"idJobVacancy": 0
        /// }
        /// </remarks>
        /// <param name="id">Identificador da vaga</param>
        /// <param name="model">Dados do aplicante</param>
        /// <returns>Objeto recém-criado</returns>
        /// <response code="200">Sucesso</response>
        // POST api/job-vacancies/applications/4
        [Route("{id}")]
        [HttpPost]
        public IActionResult Post(int id, AddJobApplicationDTO model)
        {
            Log.Information("POST new JobApplication");
            var jobVacancy = _jobVacancyRepository.GetById(id);

            if (jobVacancy == null)
                return NotFound();

            var application = new JobApplication(model.ApplicantName, model.ApplicantEmail, id);

            _jobVacancyRepository.AddApplication(application);

            return NoContent();
        }

        #endregion
    }
}