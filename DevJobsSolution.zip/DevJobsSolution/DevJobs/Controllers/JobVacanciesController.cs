﻿using DevJobs.Entities;
using DevJobs.Models;
using DevJobs.Persistence;
using DevJobs.Persistence.Repositories;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace DevJobs.Controllers
{
    [Route("api/job-vacancies")]
    [ApiController]
    public class JobVacanciesController : ControllerBase
    {
        #region Members

        IJobVacancyRepository _jobVacancyRepository;

        #endregion

        #region Constructor
        public JobVacanciesController(IJobVacancyRepository jobVacancyRepository)
        {
            _jobVacancyRepository = jobVacancyRepository;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Buscar vagas cadastradas.
        /// </summary>
        /// <returns>Lista de todas as vagas cadastradas</returns>
        /// <response code="200">Sucesso</response>
        // GET api/vacancies/list
        [HttpGet("list")]
        public IActionResult GetAll()
        {
            var jobVacancies = _jobVacancyRepository.GetAll();

            return Ok(jobVacancies);
        }

        /// <summary>
        /// Buscar vaga pelo seu identificador.
        /// </summary>
        /// <param name="id">Identificador da vaga</param>
        /// <returns>Vaga solicitada de acordo com o ID passado</returns>
        /// <response code="200">Sucesso</response>
        // GET api/jobvacancies/4
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var jobVacancy = _jobVacancyRepository.GetById(id);

            if (jobVacancy == null)
                return NotFound();

            return Ok(jobVacancy);
        }

        /// <summary>
        /// Cadastrar uma vaga de emprego.
        /// </summary>
        /// <remarks>
        /// {
        ///  "title": "Analista Jr.",
        ///  "description": "Desenvolvedor .NET C# Jr.",
        ///  "company": "System",
        ///  "isRemote": true,
        ///  "salaryRange": "2500 - 5000"
        ///  }
        /// </remarks>
        /// <param name="model">Dados da vaga</param>
        /// <returns>Objeto recém-criado</returns>
        /// <response code="200">Sucesso</response>
        /// <response code="201">Sucesso</response>
        /// <response code="400">Erro de informações</response>
        // POST api/job-vacancies/new
        [HttpPost("new-vacancy")]
        public IActionResult Post(AddJobVacancyDTO model)
        {
            Log.Information("POST new JobVacancy");
            var jobVacancy = new JobVacancy(
                model.Title,
                model.Description,
                model.Company,
                model.IsRemote,
                model.SalaryRange
                );

            _jobVacancyRepository.Add(jobVacancy);

            return CreatedAtAction("GetById", new { id = jobVacancy.Id }, jobVacancy);
        }

        /// <summary>
        /// Atualizar uma vaga de emprego.
        /// </summary>
        /// <remarks>
        /// {
        ///"title": "Analista de Suporte",
        ///"description": "Prestar suporte via HelpDesk"
        ///}
        /// </remarks>
        /// <param name="id">Identificador da vaga</param>
        /// <param name="model">Novos dados para a vaga</param>
        /// <returns>Objeto atualizado</returns>
        /// <response code="200">Sucesso</response>
        // PUT api/job-vacancies/update/4
        [HttpPut("update/{id}")]
        public IActionResult Put(int id, UpdateJobVacancyDTO model)
        {
            Log.Information("UPDATE a JobVacancy");
            var jobVacancy = _jobVacancyRepository.GetById(id);
            if (jobVacancy == null)
                return NotFound();

            jobVacancy.Update(model.Title, model.Description);
            _jobVacancyRepository.Add(jobVacancy);

            return NoContent();
        }

        /// <summary>
        /// Excluir uma vaga de emprego pelo seu identificador.
        /// </summary>
        /// <param name="id">Identificador da vaga</param>
        /// <returns>Sucesso ao excluir a vaga</returns>
        /// <response code="200">Sucesso</response>
        // DELETE api/job-vacancies/delete/4
        [HttpDelete("delete/{id}")]
        public IActionResult Delete(int id)
        {
            Log.Information("DELETE a JobVacancy");
            var jobVacancy = _jobVacancyRepository.GetById(id);
            if (jobVacancy == null)
                return NotFound();

            _jobVacancyRepository.Delete(id);

            return Ok();
        }

        #endregion
    }
}
