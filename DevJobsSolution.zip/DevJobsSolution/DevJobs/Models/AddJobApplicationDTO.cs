﻿namespace DevJobs.Models
{
    public record AddJobApplicationDTO(string ApplicantName, string ApplicantEmail, int IdJobVacancy)
    {
    }
}
