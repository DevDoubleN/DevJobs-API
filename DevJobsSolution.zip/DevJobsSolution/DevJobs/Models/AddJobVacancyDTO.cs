﻿namespace DevJobs.Models
{
    public record AddJobVacancyDTO(string Title, string Description, string Company, 
                                    bool IsRemote, string SalaryRange)
    {
    }
}
