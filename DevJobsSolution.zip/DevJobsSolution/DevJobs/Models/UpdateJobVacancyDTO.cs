﻿namespace DevJobs.Models
{
    public record UpdateJobVacancyDTO(string Title, string Description)
    {
    }
}
