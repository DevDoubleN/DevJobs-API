﻿using DevJobs.Entities;
using Microsoft.EntityFrameworkCore;

namespace DevJobs.Persistence
{
    public class DevJobsContext : DbContext
    {
        public DevJobsContext(DbContextOptions<DevJobsContext> options) : base(options)
        {

        }
        public DbSet<JobVacancy> JobVacancies { get; set; }
        public DbSet<JobApplication> JobApplications { get; set; }

        // Configurar as classes para se tornarem tabelas
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<JobVacancy>(e =>
            {
                e.HasKey(jV => jV.Id);

                e.Property(jV => jV.Id)
                .HasColumnName("ID");

                e.Property(jV => jV.Title)
                .HasColumnName("TITLE")
                .HasMaxLength(40)
                .IsRequired();

                e.Property(jV => jV.Description)
                .HasColumnName("DESCRIPTION")
                .HasMaxLength(100)
                .IsRequired();

                e.Property(jV => jV.Company)
                .HasColumnName("COMPANY")
                .HasMaxLength(40)
                .IsRequired();

                e.Property(jV => jV.IsRemote)
                .HasColumnName("IS_REMOTE")
                .IsRequired();

                e.Property(jV => jV.SalaryRange)
                .HasColumnName("SALARY_RANGE");

                e.Property(jV => jV.CreatedAt)
                .HasColumnName("CREATED_AT");

                e.HasMany(jV => jV.Applications)
                    .WithOne()
                    .HasForeignKey(jA => jA.IdJobVacancy)
                    .OnDelete(DeleteBehavior.Restrict);

                e.ToTable("TB_JOBVACANCIES");

            });

            builder.Entity<JobApplication>(e =>
            {
                e.HasKey(jA => jA.Id);

                e.Property(jA => jA.Id)
                .HasColumnName("ID");

                e.Property(jA => jA.ApplicantName)
                .HasColumnName("APPLICANT_NAME")
                .HasMaxLength(40)
                .IsRequired();

                e.Property(jA => jA.ApplicantEmail)
                .HasColumnName("APPLICANT_EMAIL")
                .HasMaxLength(40)
                .IsRequired();

                e.ToTable("TB_JOBAPPLICATIONS");
            });
        }
    }
}
