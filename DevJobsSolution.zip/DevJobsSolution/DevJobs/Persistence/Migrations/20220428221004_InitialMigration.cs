﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DevJobs.Persistence.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TB_JOBVACANCIES",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TITLE = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    DESCRIPTION = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    COMPANY = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    IS_REMOTE = table.Column<bool>(type: "bit", nullable: false),
                    SALARY_RANGE = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CREATED_AT = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_JOBVACANCIES", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TB_JOBAPPLICATIONS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    APPLICANT_NAME = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    APPLICANT_EMAIL = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    IdJobVacancy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_JOBAPPLICATIONS", x => x.ID);
                    table.ForeignKey(
                        name: "FK_TB_JOBAPPLICATIONS_TB_JOBVACANCIES_IdJobVacancy",
                        column: x => x.IdJobVacancy,
                        principalTable: "TB_JOBVACANCIES",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TB_JOBAPPLICATIONS_IdJobVacancy",
                table: "TB_JOBAPPLICATIONS",
                column: "IdJobVacancy");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TB_JOBAPPLICATIONS");

            migrationBuilder.DropTable(
                name: "TB_JOBVACANCIES");
        }
    }
}
