﻿using DevJobs.Entities;

namespace DevJobs.Persistence.Repositories
{
    public interface IJobVacancyRepository
    {
        public List<JobVacancy> GetAll();
        public JobVacancy GetById(int id);
        public void Add(JobVacancy jobVacancy);
        public void AddApplication(JobApplication jobApplication);
        public void Update(JobVacancy jobVacancy);
        public void Delete(int id);
    }
}
