﻿using DevJobs.Entities;
using Microsoft.EntityFrameworkCore;

namespace DevJobs.Persistence.Repositories
{
    public class JobVacancyRepository : IJobVacancyRepository
    {
        #region Members

        private readonly DevJobsContext _context;

        #endregion

        #region Constructor

        public JobVacancyRepository(DevJobsContext context)
        {
            _context = context;
        }

        #endregion

        #region Members IJobVacancyRepository
        public List<JobVacancy> GetAll()
        {
            var jobVacancies = _context.JobVacancies.Include(jv => jv.Applications).ToList();

            return jobVacancies;
        }
        public JobVacancy GetById(int id)
        {
            var jobVacancy = _context.JobVacancies.Include(jv => jv.Applications)
                .SingleOrDefault(jV => jV.Id == id);

            if (jobVacancy == null)
                throw new Exception("JobVacancy not found");

            return jobVacancy;
        }
        public void Add(JobVacancy jobVacancy)
        {
            _context.JobVacancies.Add(jobVacancy);
            _context.SaveChanges();
        }
        public void AddApplication(JobApplication jobApplication)
        {
            _context.JobApplications.Add(jobApplication);
            _context.SaveChanges();
        }
        public void Update(JobVacancy jobVacancy)
        {
            _context.JobVacancies.Update(jobVacancy);
            _context.SaveChanges();
        }
        public void Delete(int id)
        {
            var jobVacancy = _context.JobVacancies.SingleOrDefault(jV => jV.Id == id);

            if (jobVacancy == null)
                throw new Exception("JobVacancy not found");

            _context.JobVacancies.Remove(jobVacancy);
            _context.SaveChanges();
        }
        #endregion
    }
}
