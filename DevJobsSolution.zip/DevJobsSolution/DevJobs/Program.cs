using DevJobs.Persistence;
using DevJobs.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Sinks.MSSqlServer;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<DevJobsContext>(options => options.UseSqlServer(connectionString));

// Acesso ao Context do banco de dados em mem�ria
//builder.Services.AddDbContext<DevJobsContext>(options => options.UseInMemoryDatabase("DevJobs"));

builder.Services.AddScoped<IJobVacancyRepository, JobVacancyRepository>();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(sw =>
{
    sw.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "DevJobs",
        Version = "v1",
        Contact = new OpenApiContact
        {
            Name = "Contato LinkedIn",
            Url = new Uri("https://www.linkedin.com/in/brunno-oliveira-barbosa-5279091b0/"),
        }
    });

    var xmlFile = "DevJobs.xml";

    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

    sw.IncludeXmlComments(xmlPath);
});

// Para utilizar a aplica��o em nuvem n�o podemos usar o Serilog, pois a configura��o abaixo
// insere logs em um banco local
builder.Host.ConfigureAppConfiguration((hostingContext, config) =>
{
    Serilog.Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.MSSqlServer(connectionString,
    sinkOptions: new MSSqlServerSinkOptions()
    {
        AutoCreateSqlTable = true,
        TableName = "TB_LOGS"
    })
    .CreateLogger();
}).UseSerilog();

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
